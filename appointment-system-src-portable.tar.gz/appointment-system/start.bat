@echo off
setlocal
chcp 65001 >nul 2>nul

set ROOT_DIR=%~dp0
set BACKEND_DIR=%ROOT_DIR%backend
set GATEWAY_DIR=%ROOT_DIR%alipay-gateway
set BUILD_DIR=%BACKEND_DIR%\build

set APP_FRONTEND_PATH=%ROOT_DIR%frontend
set APP_DB_PATH=%BACKEND_DIR%\data\appointment.db
if "%APP_PUBLIC_BASE_URL%"=="" set APP_PUBLIC_BASE_URL=http://127.0.0.1:8081

echo [1/4] Checking dependencies
where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: cmake not found. Please install CMake 3.16+ and restart terminal.
  goto fail
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm not found. Please install Node.js 18+ and restart terminal.
  goto fail
)

echo [2/4] Building backend (CMake)
cmake -S "%BACKEND_DIR%" -B "%BUILD_DIR%"
if errorlevel 1 goto fail
cmake --build "%BUILD_DIR%" --config Release
if errorlevel 1 goto fail

echo [3/4] Preparing gateway dependencies (npm install)
if not exist "%GATEWAY_DIR%\node_modules" (
  call npm --prefix "%GATEWAY_DIR%" install
  if errorlevel 1 goto fail
)

if defined ALIPAY_APP_ID if defined ALIPAY_PRIVATE_KEY if defined ALIPAY_PUBLIC_KEY (
  echo [4/4] Starting Alipay gateway
  start "Alipay Gateway" cmd /k "cd /d ""%GATEWAY_DIR%"" && npm start"
  echo Gateway: http://127.0.0.1:3000
) else (
  echo [4/4] Alipay env not found, skipping gateway
  echo Set ALIPAY_APP_ID / ALIPAY_PRIVATE_KEY / ALIPAY_PUBLIC_KEY to enable payments
)

echo Starting main server: http://127.0.0.1:8081
if exist "%BUILD_DIR%\Release\appointment_server.exe" (
  "%BUILD_DIR%\Release\appointment_server.exe"
) else if exist "%BUILD_DIR%\appointment_server.exe" (
  "%BUILD_DIR%\appointment_server.exe"
) else (
  echo ERROR: backend executable not found
  goto fail
)

echo Main server exited
pause
exit /b 0

:fail
echo.
echo Startup failed. Copy the error output above and send it to me.
pause
exit /b 1
