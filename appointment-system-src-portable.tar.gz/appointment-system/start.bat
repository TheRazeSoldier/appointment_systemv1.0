@echo off
setlocal

set ROOT_DIR=%~dp0
set BACKEND_DIR=%ROOT_DIR%backend
set GATEWAY_DIR=%ROOT_DIR%alipay-gateway
set BUILD_DIR=%BACKEND_DIR%\build

echo [1/4] 检查依赖
where cmake >nul 2>nul
if errorlevel 1 (
  echo 未找到 cmake，请先安装 CMake 3.16+
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo 未找到 npm，请先安装 Node.js 18+
  exit /b 1
)

echo [2/4] 构建后端
cmake -S "%BACKEND_DIR%" -B "%BUILD_DIR%"
if errorlevel 1 exit /b 1
cmake --build "%BUILD_DIR%" --config Release
if errorlevel 1 exit /b 1

echo [3/4] 准备支付网关依赖
if not exist "%GATEWAY_DIR%\node_modules" (
  call npm --prefix "%GATEWAY_DIR%" install
  if errorlevel 1 exit /b 1
)

if defined ALIPAY_APP_ID if defined ALIPAY_PRIVATE_KEY if defined ALIPAY_PUBLIC_KEY (
  echo [4/4] 启动支付宝网关
  start "Alipay Gateway" cmd /k "cd /d "%GATEWAY_DIR%" && npm start"
  echo 支付宝网关地址: http://127.0.0.1:3000
) else (
  echo [4/4] 未检测到支付宝环境变量，跳过支付网关启动
  echo 如需支付功能，请先设置 ALIPAY_APP_ID / ALIPAY_PRIVATE_KEY / ALIPAY_PUBLIC_KEY
)

echo 主站即将启动: http://127.0.0.1:8081
if exist "%BUILD_DIR%\Release\appointment_server.exe" (
  "%BUILD_DIR%\Release\appointment_server.exe"
) else if exist "%BUILD_DIR%\appointment_server.exe" (
  "%BUILD_DIR%\appointment_server.exe"
) else (
  echo 未找到后端可执行文件
  exit /b 1
)
