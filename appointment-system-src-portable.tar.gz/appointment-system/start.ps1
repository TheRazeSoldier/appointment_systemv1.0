$ErrorActionPreference = "Stop"

$RootDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BackendDir = Join-Path $RootDir "backend"
$GatewayDir = Join-Path $RootDir "alipay-gateway"
$BuildDir = Join-Path $BackendDir "build"

$env:APP_FRONTEND_PATH = (Join-Path $RootDir "frontend")
$env:APP_DB_PATH = (Join-Path $BackendDir "data\appointment.db")
if (-not $env:APP_PUBLIC_BASE_URL) { $env:APP_PUBLIC_BASE_URL = "http://127.0.0.1:8081" }

Write-Host "[1/4] Checking dependencies"
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) { throw "cmake not found. Install CMake 3.16+." }
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { throw "npm not found. Install Node.js 18+." }

Write-Host "[2/4] Building backend (CMake)"
cmake -S $BackendDir -B $BuildDir
cmake --build $BuildDir --config Release

Write-Host "[3/4] Preparing gateway dependencies (npm install)"
if (-not (Test-Path (Join-Path $GatewayDir "node_modules"))) {
  npm --prefix $GatewayDir install
}

$HasAlipayEnv = $env:ALIPAY_APP_ID -and $env:ALIPAY_PRIVATE_KEY -and $env:ALIPAY_PUBLIC_KEY
if ($HasAlipayEnv) {
  Write-Host "[4/4] Starting Alipay gateway"
  Start-Process -WorkingDirectory $GatewayDir -FilePath "cmd.exe" -ArgumentList "/k", "npm start" | Out-Null
  Write-Host "Gateway: http://127.0.0.1:3000"
} else {
  Write-Host "[4/4] Alipay env not found, skipping gateway"
  Write-Host "Set ALIPAY_APP_ID / ALIPAY_PRIVATE_KEY / ALIPAY_PUBLIC_KEY to enable payments"
}

$exe1 = Join-Path $BuildDir "Release\appointment_server.exe"
$exe2 = Join-Path $BuildDir "appointment_server.exe"
$exe3 = Join-Path $BuildDir "appointment_server"

Write-Host "Starting main server: http://127.0.0.1:8081"
if (Test-Path $exe1) { & $exe1; exit $LASTEXITCODE }
if (Test-Path $exe2) { & $exe2; exit $LASTEXITCODE }
if (Test-Path $exe3) { & $exe3; exit $LASTEXITCODE }
throw "backend executable not found under backend/build"
