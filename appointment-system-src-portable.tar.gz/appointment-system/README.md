# appointment-system

## 支付与运行

## 一键启动

- Linux / macOS：在项目根目录执行 `bash start.sh`
- Windows（推荐 PowerShell）：在项目根目录执行 `.\start.ps1`
- Windows（cmd / 双击）：运行 `start.bat`
- 脚本会自动：
  - 用 CMake 构建后端
  - 检查并安装 `alipay-gateway` 依赖
  - 如果已配置支付宝环境变量，则自动启动支付网关
  - 启动主站 `http://127.0.0.1:8081`

未配置 `ALIPAY_APP_ID`、`ALIPAY_PRIVATE_KEY`、`ALIPAY_PUBLIC_KEY` 时，系统仍可启动，但支付功能不可用。

如果启动后服务列表为空，可用 `seed-batch.py` 批量生成演示数据（需要 Python 3）：

```bash
python seed-batch.py
```

## 跨平台本地编译运行（推荐）

### 1. 环境准备

- Git（用于下载源码，可选）
- CMake 3.16+
- C/C++ 编译器
  - Windows：Visual Studio 2022（含 C++ Desktop 开发）或 MinGW-w64
  - macOS：Xcode Command Line Tools
  - Linux：g++/clang++
- Node.js 18+（用于 `alipay-gateway`）

### 2. 构建并运行主后端（CMake）

```bash
cd backend
cmake -S . -B build
cmake --build build --config Release
./build/appointment_server
```

默认监听 `http://127.0.0.1:8081`，并挂载 `frontend/` 静态页面。

### 3. 启动支付宝网关（Node.js）

```bash
cd alipay-gateway
npm install
npm start
```

网关运行前需要设置支付宝相关环境变量，示例见 `alipay-gateway/.env.example`。

### 1. 启动支付宝网关

```bash
cd alipay-gateway
npm install
export ALIPAY_APP_ID="你的支付宝应用ID"
export ALIPAY_PRIVATE_KEY="你的应用私钥"
export ALIPAY_PUBLIC_KEY="你的支付宝公钥"
# 生产环境改成 https://openapi.alipay.com/gateway.do
export ALIPAY_GATEWAY="https://openapi-sandbox.dl.alipaydev.com/gateway.do"
npm start
```

默认监听 `http://127.0.0.1:3000`。

### 2. 启动主后端

```bash
cd backend
make
./appointment_server
```

默认监听 `http://127.0.0.1:8081`。

如需让支付宝异步通知回调到公网地址，请先设置：

```bash
export APP_PUBLIC_BASE_URL="https://你的公网域名"
```

然后再启动主后端。支付回跳地址和异步通知地址都会基于这个值生成。

### 3. 支付说明

- 当前已接入支付宝沙箱电脑网站支付
- 网页支付使用 `alipay.trade.page.pay`
- 支付结果以异步通知或主动查询为准，不以同步回跳为准
- 已接入支付宝官方退款接口与退款查询接口
- Node 网关使用支付宝官方 `alipay-sdk`
- C++ 主服务负责预约、订单和数据报表

### 4. 沙箱测试账号

- 商家账号：`tfciji9399@sandbox.com`
- 买家账号：`dcwage4119@sandbox.com`
- 买家登录密码：`111111`
- 买家支付密码：`111111`

### 5. 安全提醒

- 不要把 `ALIPAY_PRIVATE_KEY`、`ALIPAY_PUBLIC_KEY`、`ALIPAY_APP_ID` 提交到仓库
- 正式上线前请切换生产网关、生产 APPID、生产密钥
- `APP_PUBLIC_BASE_URL` 必须配置为可公网访问的 HTTPS 域名
