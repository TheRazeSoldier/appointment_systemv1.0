#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
GATEWAY_DIR="$ROOT_DIR/alipay-gateway"
BUILD_DIR="$BACKEND_DIR/build"

echo "[1/4] 检查依赖"
command -v cmake >/dev/null 2>&1 || { echo "未找到 cmake，请先安装 CMake 3.16+"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "未找到 npm，请先安装 Node.js 18+"; exit 1; }

echo "[2/4] 构建后端"
cmake -S "$BACKEND_DIR" -B "$BUILD_DIR"
cmake --build "$BUILD_DIR" --config Release

echo "[3/4] 准备支付网关依赖"
if [ ! -d "$GATEWAY_DIR/node_modules" ]; then
  npm --prefix "$GATEWAY_DIR" install
fi

if [ -n "$ALIPAY_APP_ID" ] && [ -n "$ALIPAY_PRIVATE_KEY" ] && [ -n "$ALIPAY_PUBLIC_KEY" ]; then
  echo "[4/4] 启动支付宝网关"
  (
    cd "$GATEWAY_DIR"
    npm start
  ) &
  GATEWAY_PID=$!
  echo "支付宝网关已启动，PID: $GATEWAY_PID，地址: http://127.0.0.1:3000"
else
  echo "[4/4] 未检测到支付宝环境变量，跳过支付网关启动"
  echo "如需支付功能，请先设置 ALIPAY_APP_ID / ALIPAY_PRIVATE_KEY / ALIPAY_PUBLIC_KEY"
fi

echo "主站即将启动: http://127.0.0.1:8081"
echo "按 Ctrl+C 可停止主站；若同时启动了网关，可能需要手动结束后台 Node 进程。"

if [ -x "$BUILD_DIR/appointment_server" ]; then
  exec "$BUILD_DIR/appointment_server"
elif [ -x "$BUILD_DIR/Release/appointment_server" ]; then
  exec "$BUILD_DIR/Release/appointment_server"
else
  echo "未找到后端可执行文件"
  exit 1
fi
