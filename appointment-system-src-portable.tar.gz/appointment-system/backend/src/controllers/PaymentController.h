#pragma once
#include <httplib.h>
#include "../services/DatabaseService.h"

class PaymentController {
public:
    static void registerRoutes(httplib::Server& svr, DatabaseService& db);
    static std::string buildTransactionId(int appointmentId);
};
