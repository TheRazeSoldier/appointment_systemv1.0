#include "PaymentController.h"
#include "../middleware/AuthMiddleware.h"
#include "../config/config.h"
#include "../../include/json.hpp"
#include "../../include/httplib.h"
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>

using json = nlohmann::json;

namespace {
std::string getBaseUrl() {
    auto& config = Config::getInstance();
    return config.getPublicBaseUrl();
}

std::string formatAmount(double amount) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2) << amount;
    return oss.str();
}

json postGatewayJson(const std::string& path, const json& payload, int* status = nullptr) {
    httplib::Client client("http://127.0.0.1", 3000);
    client.set_read_timeout(20, 0);
    client.set_write_timeout(20, 0);
    auto resp = client.Post(path.c_str(), payload.dump(), "application/json");
    if (!resp) {
        if (status) *status = 0;
        return json();
    }
    if (status) *status = resp->status;
    return json::parse(resp->body, nullptr, false);
}

std::string buildRefundRequestId(int appointmentId) {
    return "REFUND_" + std::to_string(appointmentId);
}
}

std::string PaymentController::buildTransactionId(int appointmentId) {
    return "APPT_" + std::to_string(appointmentId);
}

void PaymentController::registerRoutes(httplib::Server& svr, DatabaseService& db) {
    svr.Post("/api/payment/pay", [&db](const httplib::Request& req, httplib::Response& res) {
        AuthUser authUser;
        if (!AuthMiddleware::requireAuth(req, res, authUser)) return;

        try {
            auto body = json::parse(req.body);
            if (!body.contains("appointment_id")) {
                res.status = 400;
                res.set_content(R"({"error": "Missing appointment_id"})", "application/json");
                return;
            }

            int appointmentId = body["appointment_id"].get<int>();
            auto appt = db.getAppointmentById(appointmentId);
            if (appt.id == 0) {
                res.status = 404;
                res.set_content(R"({"error": "Appointment not found"})", "application/json");
                return;
            }
            if (appt.user_id != authUser.userId) {
                res.status = 403;
                res.set_content(R"({"error": "Forbidden"})", "application/json");
                return;
            }
            if (appt.payment_status == "paid") {
                res.status = 400;
                res.set_content(R"({"error": "Appointment already paid"})", "application/json");
                return;
            }

            auto service = db.getServiceById(appt.service_id);
            if (service.id == 0 || service.price <= 0) {
                res.status = 400;
                res.set_content(R"({"error": "Invalid service price"})", "application/json");
                return;
            }

            const std::string transactionId = buildTransactionId(appointmentId);
            if (!db.updatePaymentStatus(appointmentId, "pending", transactionId)) {
                res.status = 500;
                res.set_content(R"({"error": "Failed to prepare payment order"})", "application/json");
                return;
            }

            json gatewayPayload = {
                {"out_trade_no", transactionId},
                {"subject", service.name},
                {"total_amount", formatAmount(service.price)},
                {"appointment_id", appointmentId},
                {"return_url", getBaseUrl() + "/api/payment/return"},
                {"notify_url", getBaseUrl() + "/api/payment/notify"}
            };

            int gatewayStatus = 0;
            auto gatewayJson = postGatewayJson("/gateway/pay", gatewayPayload, &gatewayStatus);
            if (gatewayStatus == 0 || gatewayJson.is_discarded()) {
                res.status = 502;
                res.set_content(R"({"error": "Alipay gateway service unavailable"})", "application/json");
                return;
            }
            res.status = gatewayStatus;
            res.set_content(gatewayJson.dump(), "application/json");
        } catch (const std::exception& e) {
            std::cerr << "Payment error: " << e.what() << std::endl;
            res.status = 400;
            res.set_content(R"({"error": "Invalid JSON format"})", "application/json");
        }
    });

    svr.Get("/api/payment/return", [&db](const httplib::Request& req, httplib::Response& res) {
        std::string outTradeNo = req.has_param("out_trade_no") ? req.get_param_value("out_trade_no") : "";
        if (outTradeNo.empty()) {
            res.status = 400;
            res.set_content("缺少商户订单号", "text/plain; charset=UTF-8");
            return;
        }

        json queryPayload = {{"out_trade_no", outTradeNo}};
        int gatewayStatus = 0;
        auto queryJson = postGatewayJson("/gateway/query", queryPayload, &gatewayStatus);
        if (gatewayStatus != 200 || queryJson.is_discarded()) {
            res.status = 502;
            res.set_content("支付结果查询失败，请稍后在我的预约中刷新查看。", "text/plain; charset=UTF-8");
            return;
        }

        auto appt = db.getAppointmentByTransactionId(outTradeNo);
        if (appt.id == 0) {
            res.status = 404;
            res.set_content("未找到对应预约记录。", "text/plain; charset=UTF-8");
            return;
        }

        std::string tradeStatus = queryJson.value("trade_status", "");
        if (tradeStatus == "TRADE_SUCCESS" || tradeStatus == "TRADE_FINISHED") {
            db.updatePaymentStatus(appt.id, "paid", outTradeNo);
            res.set_content("支付成功，您可以返回“我的预约”查看最新状态。", "text/plain; charset=UTF-8");
            return;
        }

        if (tradeStatus == "WAIT_BUYER_PAY") {
            res.set_content("支付尚未完成，请稍后在“我的预约”继续支付。", "text/plain; charset=UTF-8");
            return;
        }

        db.updatePaymentStatus(appt.id, "failed", outTradeNo);
        res.set_content("支付未成功，请返回“我的预约”重试。", "text/plain; charset=UTF-8");
    });

    svr.Post("/api/payment/notify", [&db](const httplib::Request& req, httplib::Response& res) {
        json verifyPayload = json::object();
        for (const auto& param : req.params) {
            verifyPayload[param.first] = param.second;
        }

        httplib::Client verifyClient("http://127.0.0.1", 3000);
        verifyClient.set_read_timeout(20, 0);
        verifyClient.set_write_timeout(20, 0);
        auto verifyResp = verifyClient.Post("/gateway/verify-notify", verifyPayload.dump(), "application/json");
        if (!verifyResp || verifyResp->status != 200) {
            res.status = 502;
            res.set_content("failure", "text/plain");
            return;
        }

        auto verifyJson = json::parse(verifyResp->body, nullptr, false);
        if (verifyJson.is_discarded() || !verifyJson.value("verified", false)) {
            res.status = 400;
            res.set_content("failure", "text/plain");
            return;
        }

        std::string outTradeNo;
        std::string tradeStatus;
        std::string totalAmount;
        std::string appId;
        std::string sellerId;

        for (const auto& param : req.params) {
            if (param.first == "out_trade_no") outTradeNo = param.second;
            else if (param.first == "trade_status") tradeStatus = param.second;
            else if (param.first == "total_amount") totalAmount = param.second;
            else if (param.first == "app_id") appId = param.second;
            else if (param.first == "seller_id") sellerId = param.second;
        }

        auto appt = db.getAppointmentByTransactionId(outTradeNo);
        if (appt.id == 0) {
            res.status = 404;
            res.set_content("failure", "text/plain");
            return;
        }
        if (appt.payment_status == "paid" && (tradeStatus == "TRADE_SUCCESS" || tradeStatus == "TRADE_FINISHED")) {
            res.set_content("success", "text/plain");
            return;
        }

        auto service = db.getServiceById(appt.service_id);
        if (service.id == 0 || formatAmount(service.price) != totalAmount) {
            res.status = 400;
            res.set_content("failure", "text/plain");
            return;
        }

        if (appId != "9021000165631392" || sellerId != "2088721102906231") {
            res.status = 400;
            res.set_content("failure", "text/plain");
            return;
        }

        if (tradeStatus == "TRADE_SUCCESS" || tradeStatus == "TRADE_FINISHED") {
            db.updatePaymentStatusDetailed(appt.id, "paid", outTradeNo, appt.refund_request_id);
        } else if (tradeStatus == "TRADE_CLOSED") {
            db.updatePaymentStatusDetailed(appt.id, "failed", outTradeNo, appt.refund_request_id);
        }

        res.set_content("success", "text/plain");
    });

    svr.Post("/api/payment/refund", [&db](const httplib::Request& req, httplib::Response& res) {
        AuthUser authUser;
        if (!AuthMiddleware::requireAuth(req, res, authUser)) return;

        try {
            auto body = json::parse(req.body);
            if (!body.contains("appointment_id")) {
                res.status = 400;
                res.set_content(R"({"error": "Missing appointment_id"})", "application/json");
                return;
            }

            int appointmentId = body["appointment_id"].get<int>();
            auto appt = db.getAppointmentById(appointmentId);
            if (appt.id == 0) {
                res.status = 404;
                res.set_content(R"({"error": "Appointment not found"})", "application/json");
                return;
            }
            if (appt.user_id != authUser.userId) {
                res.status = 403;
                res.set_content(R"({"error": "Forbidden"})", "application/json");
                return;
            }
            if (appt.payment_status != "paid") {
                res.status = 400;
                res.set_content(R"({"error": "Appointment not paid, cannot refund"})", "application/json");
                return;
            }
            const std::string refundRequestId = appt.refund_request_id.empty() ? buildRefundRequestId(appointmentId) : appt.refund_request_id;
            auto service = db.getServiceById(appt.service_id);
            if (service.id == 0 || service.price <= 0) {
                res.status = 400;
                res.set_content(R"({"error": "Invalid service price"})", "application/json");
                return;
            }

            int refundStatus = 0;
            json refundPayload = {
                {"out_trade_no", appt.transaction_id},
                {"refund_amount", formatAmount(service.price)},
                {"out_request_no", refundRequestId},
                {"refund_reason", "用户申请退款"}
            };
            auto refundJson = postGatewayJson("/gateway/refund", refundPayload, &refundStatus);
            if (refundStatus != 200 || refundJson.is_discarded()) {
                res.status = refundStatus == 0 ? 502 : refundStatus;
                res.set_content(json{{"error", refundJson.value("error", "Refund request failed")}}.dump(), "application/json");
                return;
            }

            int refundQueryStatus = 0;
            auto refundQueryJson = postGatewayJson("/gateway/refund-query", {
                {"out_trade_no", appt.transaction_id},
                {"out_request_no", refundRequestId}
            }, &refundQueryStatus);
            if (refundQueryStatus != 200 || refundQueryJson.is_discarded()) {
                res.status = refundQueryStatus == 0 ? 502 : refundQueryStatus;
                res.set_content(json{{"error", refundQueryJson.value("error", "Refund status query failed")}}.dump(), "application/json");
                return;
            }

            if (refundQueryJson.value("refund_status", "") != "REFUND_SUCCESS") {
                res.status = 400;
                res.set_content(json{{"error", "Refund not completed"}}.dump(), "application/json");
                return;
            }

            db.updatePaymentStatusDetailed(appointmentId, "refunded", appt.transaction_id, refundRequestId);
            db.updateAppointmentStatus(appointmentId, "cancelled");
            res.set_content(json{{"message", "Refund successful"}, {"payment_status", "refunded"}, {"refund_request_id", refundRequestId}}.dump(), "application/json");
        } catch (const std::exception& e) {
            std::cerr << "Refund error: " << e.what() << std::endl;
            res.status = 400;
            res.set_content(R"({"error": "Invalid JSON format"})", "application/json");
        }
    });

    svr.Post("/api/payment/sync", [&db](const httplib::Request& req, httplib::Response& res) {
        AuthUser authUser;
        if (!AuthMiddleware::requireAuth(req, res, authUser)) return;

        try {
            auto body = json::parse(req.body);
            if (!body.contains("appointment_id")) {
                res.status = 400;
                res.set_content(R"({"error": "Missing appointment_id"})", "application/json");
                return;
            }

            int appointmentId = body["appointment_id"].get<int>();
            auto appt = db.getAppointmentById(appointmentId);
            if (appt.id == 0) {
                res.status = 404;
                res.set_content(R"({"error": "Appointment not found"})", "application/json");
                return;
            }
            if (appt.user_id != authUser.userId) {
                res.status = 403;
                res.set_content(R"({"error": "Forbidden"})", "application/json");
                return;
            }
            if (appt.transaction_id.empty()) {
                res.set_content(json{{"payment_status", appt.payment_status}}.dump(), "application/json");
                return;
            }

            int queryStatus = 0;
            auto queryJson = postGatewayJson("/gateway/query", {{"out_trade_no", appt.transaction_id}}, &queryStatus);
            if (queryStatus == 200 && !queryJson.is_discarded()) {
                std::string tradeStatus = queryJson.value("trade_status", "");
                if (tradeStatus == "TRADE_SUCCESS" || tradeStatus == "TRADE_FINISHED") {
                    db.updatePaymentStatusDetailed(appt.id, "paid", appt.transaction_id, appt.refund_request_id);
                    appt.payment_status = "paid";
                } else if (tradeStatus == "WAIT_BUYER_PAY") {
                    appt.payment_status = "pending";
                } else if (tradeStatus == "TRADE_CLOSED") {
                    db.updatePaymentStatusDetailed(appt.id, "failed", appt.transaction_id, appt.refund_request_id);
                    appt.payment_status = "failed";
                }
            }

            res.set_content(json{{"payment_status", appt.payment_status}, {"transaction_id", appt.transaction_id}}.dump(), "application/json");
        } catch (const std::exception& e) {
            std::cerr << "Payment sync error: " << e.what() << std::endl;
            res.status = 400;
            res.set_content(R"({"error": "Invalid JSON format"})", "application/json");
        }
    });
}
