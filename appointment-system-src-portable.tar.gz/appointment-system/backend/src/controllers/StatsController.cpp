#include "StatsController.h"
#include "../../include/json.hpp"
#include "../services/DatabaseService.h"
#include "../middleware/AuthMiddleware.h"
#include <map>

using json = nlohmann::json;

void StatsController::registerRoutes(httplib::Server& svr) {
    svr.Get("/api/stats", [](const httplib::Request& req, httplib::Response& res) {
        auto& db = DatabaseService::getInstance();
        auto stats = db.getStats();
        
        res.set_content(json{
            {"total_users", stats.total_users},
            {"total_providers", stats.total_providers},
            {"total_services", stats.total_services},
            {"total_appointments", stats.total_appointments},
            {"total_revenue", stats.total_revenue}
        }.dump(), "application/json");
    });

    svr.Get("/api/stats/provider", [](const httplib::Request& req, httplib::Response& res) {
        AuthUser authUser;
        if (!AuthMiddleware::requireRole(req, res, authUser, "provider")) return;
        
        auto& db = DatabaseService::getInstance();
        auto provider = db.getProviderByUserId(authUser.userId);
        if (provider.id == 0) {
            res.status = 404;
            res.set_content(R"({"error": "Provider not found"})", "application/json");
            return;
        }

        auto appointments = db.getAppointmentsByProvider(provider.id);
        auto services = db.getServicesByProvider(provider.id);
        auto reviews = db.getReviewsByProvider(provider.id);
        
        int total_appointments = appointments.size();
        int completed_appointments = 0;
        int pending_appointments = 0;
        int paid_appointments = 0;
        int total_views = 0;
        double total_revenue = 0.0;
        double average_rating = 0.0;

        std::map<std::string, double> revenue_by_month;
        std::map<int, int> appointment_count_by_service;
        std::map<int, int> paid_count_by_service;
        std::map<int, double> revenue_by_service;
        std::map<int, int> review_count_by_service;
        std::map<int, int> rating_sum_by_service;

        for (const auto& review : reviews) {
            rating_sum_by_service[review.service_id] += review.rating;
            review_count_by_service[review.service_id] += 1;
            average_rating += review.rating;
        }
        if (!reviews.empty()) {
            average_rating /= reviews.size();
        }

        for (const auto& a : appointments) {
            if (a.status == "completed") completed_appointments++;
            if (a.status == "pending") pending_appointments++;
            appointment_count_by_service[a.service_id] += 1;
            if (a.payment_status == "paid") {
                paid_appointments++;
                auto service = db.getServiceById(a.service_id);
                total_revenue += service.price;
                paid_count_by_service[a.service_id] += 1;
                revenue_by_service[a.service_id] += service.price;
                
                if (a.appointment_date.size() >= 7) {
                    std::string month = a.appointment_date.substr(0, 7);
                    revenue_by_month[month] += service.price;
                }
            }
        }

        json service_stats = json::array();
        for (const auto& service : services) {
            total_views += service.view_count;
            double serviceRating = 0.0;
            if (review_count_by_service[service.id] > 0) {
                serviceRating = static_cast<double>(rating_sum_by_service[service.id]) / review_count_by_service[service.id];
            }
            service_stats.push_back({
                {"service_id", service.id},
                {"service_name", service.name},
                {"appointments", appointment_count_by_service[service.id]},
                {"paid_appointments", paid_count_by_service[service.id]},
                {"revenue", revenue_by_service[service.id]},
                {"views", service.view_count},
                {"rating", serviceRating},
                {"review_count", review_count_by_service[service.id]}
            });
        }

        json monthly_revenue = json::array();
        for (const auto& [month, revenue] : revenue_by_month) {
            monthly_revenue.push_back({
                {"month", month},
                {"revenue", revenue}
            });
        }

        json response = {
            {"total_appointments", total_appointments},
            {"completed_appointments", completed_appointments},
            {"pending_appointments", pending_appointments},
            {"paid_appointments", paid_appointments},
            {"total_revenue", total_revenue},
            {"total_views", total_views},
            {"average_rating", average_rating},
            {"service_count", static_cast<int>(services.size())},
            {"review_count", static_cast<int>(reviews.size())},
            {"monthly_revenue", monthly_revenue},
            {"service_stats", service_stats}
        };

        res.set_content(response.dump(), "application/json");
    });
}
